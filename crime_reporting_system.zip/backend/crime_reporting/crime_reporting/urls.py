from django.contrib import admin
from django.urls import path
from reports import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name="home"),
    path('report/', views.report_crime, name="report_crime"),
    path('api/reports/', views.get_reports_json, name="get_reports_json"),
]

from django.shortcuts import render, redirect
from .models import CrimeReport
from django.http import JsonResponse

def home(request):
    reports = CrimeReport.objects.all()
    return render(request, "home.html", {"reports": reports})

def report_crime(request):
    if request.method == "POST":
        crime_type = request.POST.get("crime_type")
        description = request.POST.get("description")
        latitude = request.POST.get("latitude")
        longitude = request.POST.get("longitude")

        CrimeReport.objects.create(
            crime_type=crime_type,
            description=description,
            latitude=latitude,
            longitude=longitude,
            reporter=request.user if request.user.is_authenticated else None
        )
        return redirect("home")
    return render(request, "report.html")

def get_reports_json(request):
    reports = list(CrimeReport.objects.values())
    return JsonResponse(reports, safe=False)
